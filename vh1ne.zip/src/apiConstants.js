export const VALIDATE_CREDENTIALS = "/verifyCredentials/";
export const FORGOT_PASSWORD = "/forgotPassword/";
export const GET_SHARES = "/getShares/";
