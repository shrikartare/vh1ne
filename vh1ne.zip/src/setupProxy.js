const addMockServerMiddleware = require("./mock-server/mockServerMiddleware");

module.exports = function (app) {
  addMockServerMiddleware(app);
};
