import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  LandingPageView: "LOGIN",
};
const landingPageSlice = createSlice({
  name: "landingPage",
  initialState,
  reducers: {
    updateView(state, action) {
      state.LandingPageView = action.payload;
    },
  },
});

export const { updateView } = landingPageSlice.actions;

export default landingPageSlice.reducer;
