import React from "react";
import { useSelector } from "react-redux";
import { Route, Switch } from "react-router-dom";
import "../../App.scss";
import Login from "../login/Login";
import Register from "../register/Register";
import ForgotPassword from "../forgot-password/ForgotPassword";
import Home from "../home/Home";

const LandingPage = () => {
  // const view = useSelector((state) => state.LandingPageView);
  return (
    <>
      <Switch>
        <Route exact path="/" component={Login} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/register" component={Register} />
        <Route exact path="/forgot-password" component={ForgotPassword} />
        <Route exact path="/home" component={Home} />
      </Switch>
    </>
  );
};
export default LandingPage;
