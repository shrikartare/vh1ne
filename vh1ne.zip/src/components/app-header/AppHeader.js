import React from "react";
import logo from "../../assets/images/logo.svg";
import "./appHeader.scss";

const AppHeader = () => {
  return (
    <>
      <div className="app-header">
        {/* <img src={logo} alt="vh1ne"></img> */}
      </div>
    </>
  );
};

export default AppHeader;
