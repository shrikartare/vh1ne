export const bindValidatonRules = (rules, register) => {
  rules.forEach((rule) => {
    register(rule.name, rule);
  });
};
