import React from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";
import "../landing-page/landingPage.scss";
import validationRules from "./register.rules";
import logo from "../../assets/images/logo.svg";

const Register = () => {
  const history = useHistory();
  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    reValidateMode: "onChange",
    shouldFocusError: true,
  });
  console.log("errors", errors);

  const onButtonClick = () => {
    history.push("/login");
  };
  const onSubmit = (data) => {
    console.log("data", data);
  };
  return (
    <>
      <div className="landing-page-container">
        <img src={logo} className="App-logo" alt="logo" />
        <Form>
          <Form.Group as={Row} controlId="username">
            <Col sm={12}>
              <Form.Control
                placeholder="UserName"
                type="text"
                className={errors.username ? "errorControl" : ""}
                {...register("username", validationRules.username)}
              />
              {errors?.username && (
                <p className="errorMessage">{errors.username.message}</p>
              )}
            </Col>
          </Form.Group>
          <Form.Group as={Row} controlId="email">
            <Col sm={12}>
              <Form.Control
                placeholder="E-mail"
                type="text"
                className={errors.username ? "errorControl" : ""}
                {...register("email", validationRules.email)}
              />
              {errors?.email && (
                <p className="errorMessage">{errors.email.message}</p>
              )}
            </Col>
          </Form.Group>
          <Form.Group as={Row} controlId="password">
            <Col sm={12}>
              <Form.Control
                placeholder="Password"
                type="password"
                className={errors.password ? "errorControl" : ""}
                {...register("password", validationRules.password)}
              />
              {/*password between 6 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character */}
              {errors?.password && (
                <p className="errorMessage">{errors.password.message}</p>
              )}
            </Col>
          </Form.Group>
          <Form.Group as={Row} controlId="confirmpassword">
            <Col sm={12}>
              <Form.Control
                placeholder="Confirm Password"
                type="password"
                className={errors.password ? "errorControl" : ""}
                {...register("confirmPassword", {
                  validate: (value) =>
                    value === watch("password") || "Passwords should match",
                })}
              />
              {errors?.confirmPassword && (
                <p className="errorMessage">{errors.confirmPassword.message}</p>
              )}
            </Col>
          </Form.Group>
          <Form.Group as={Row}>
            <Col sm={12}>
              <Button type="submit" onClick={handleSubmit(onSubmit)}>
                Register
              </Button>
            </Col>
          </Form.Group>
          <Row>
            <Button
              id="login"
              variant="link"
              className="center-align"
              onClick={onButtonClick}
            >
              Login
            </Button>
          </Row>
        </Form>
      </div>
    </>
  );
};

export default Register;
