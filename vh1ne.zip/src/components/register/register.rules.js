const validationRules = {
  username: {
    required: "Username is required",
    pattern: {
      value: /^[0-9a-zA-Z]+$/,
      message: "Username is not valid",
    },
    minLength: {
      value: 4,
      message: "Username should be greater then 4 characters",
    },
    maxLength: {
      value: 12,
      message: "Username should be less then 12 characters",
    },
  },
  email: {
    required: "Email is required",
    pattern: {
      value: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
      message: "Email Address is invalid",
    },
  },
  password: {
    required: "Password is required",
    pattern: {
      value: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/,
      message: "Password should be valid",
    },
  },
};
export default validationRules;
