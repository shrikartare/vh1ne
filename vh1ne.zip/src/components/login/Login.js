import React from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import axios from "axios";
import logo from "../../assets/images/logo.svg";
import * as API_CONSTANTS from "../../apiConstants";
import "../landing-page/landingPage.scss";
import { updateView } from "../landing-page/landingPageSlice";

const Login = () => {
  // const dispatch = useDispatch(); //Redux
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    reValidateMode: "onChange",
    shouldFocusError: true,
  });
  const history = useHistory();
  const onButtonClick = (event) => {
    switch (event.target.id) {
      case "register":
        history.push("/register");
        break;
      case "forgotPwd":
        history.push("/forgot-password");
        break;
      default:
        history.push("/");
    }
    // dispatch(updateView("REGISTER")); //Redux
  };

  const validateCredentials = async (data) => {
    const requestObj = {
      username: data.username,
      password: data.password,
    };
    try {
      const response = await axios.post(
        API_CONSTANTS.VALIDATE_CREDENTIALS,
        requestObj
      );
      console.log(response, "Login Successful");
      history.push("/home");
    } catch (error) {
      console.log(error);
    }
  };
  const onLogin = (data) => {
    validateCredentials(data);
  };
  return (
    <>
      <div className="landing-page-container">
        <img src={logo} className="App-logo" alt="logo" />
        <Form>
          <Form.Group as={Row} controlId="username">
            <Col sm={12}>
              <Form.Control
                placeholder="Username"
                type="text"
                className={errors.username ? "errorControl" : ""}
                {...register("username", { required: "Username is required" })}
              />
              {errors?.username && (
                <p className="errorMessage">{errors.username.message}</p>
              )}
            </Col>
          </Form.Group>
          <Form.Group as={Row} controlId="password" className="pwd-form-cntrl">
            <Col sm={12}>
              <Form.Control
                placeholder="Password"
                type="password"
                className={errors.password ? "errorControl" : ""}
                {...register("password", { required: "Password is required" })}
              />
              {errors?.password && (
                <p className="errorMessage">{errors.password.message}</p>
              )}
            </Col>
          </Form.Group>
          <Row>
            <Button id="register" variant="link" onClick={onButtonClick}>
              Register
            </Button>
            <Button
              id="forgotPwd"
              variant="link"
              onClick={onButtonClick}
              className="forgot-pwd"
            >
              Forgot Password
            </Button>
          </Row>
          <Form.Group as={Row}>
            <Col sm={12}>
              <Button id="login" type="submit" onClick={handleSubmit(onLogin)}>
                LOG IN
              </Button>
            </Col>
          </Form.Group>
        </Form>
      </div>
    </>
  );
};

export default Login;
