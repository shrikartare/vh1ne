import React from "react";

const Home = () => {
  return <>Home Page. !!!Login Successfull</>;
};

export default Home;
