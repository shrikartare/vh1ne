import React, { useEffect, useState } from "react";
import { Row, Col } from "react-bootstrap";
import axios from "axios";
import { GET_SHARES } from "../../apiConstants";
import AppHeader from "../app-header/AppHeader";
import DataTable from "../data-table/DataTable";
import SideNavBar from "../side-navbar/SideNavBar";
import "./home.scss";

const Home = () => {
  const [tableData, setTableData] = useState([]);
  const [columnHeaders, setColumnHeaders] = useState([]);
  const createColumn = (key) => {
    return {
      Header: key.toUpperCase(),
      accessor: key,
    };
  };
  const getShareList = async () => {
    const columnHeaders = [];
    const response = await axios.get(GET_SHARES);
    const shareList = response.data.shareList;
    setTableData(response.data.shareList);
    let keys = Object.keys(shareList[0]);
    keys.forEach((key) => {
      columnHeaders.push(createColumn(key));
    });
    setColumnHeaders(columnHeaders);
  };
  useEffect(() => {
    getShareList();
  }, []);
  // const columns = [
  //   {
  //     Header: "Company",
  //     accessor: "company",
  //   },
  //   {
  //     Header: "Market Cap",
  //     accessor: "mcap",
  //   },
  //   {
  //     Header: "Value",
  //     accessor: "value",
  //   },
  // ];

  return (
    <>
      <AppHeader />
      <SideNavBar />
      <div className="main-content">
        <div className="table-container">
          <DataTable
            data={tableData}
            columns={columnHeaders}
            isServerPagination={false}
          />
        </div>
      </div>
    </>
  );
};

export default Home;
