import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  users: [
    {
      id: 1,
      name: "Shrikar",
    },
  ],
};

const homePageSlice = createSlice({
  name: "homePage",
  initialState,
  reducers: {
    updateData(state, action) {
      state.users = action.payload;
    },
  },
});

export default homePageSlice.reducer;
