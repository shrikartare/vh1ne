/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import { useTable, usePagination, useSortBy } from "react-table";
import "./DataTable.scss";

const DataTable = ({ data, columns, totalRecords, isServerPagination }) => {
  const tableData = React.useMemo(() => data, [data]);
  const tablecolumns = React.useMemo(() => columns, [columns]);
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = useTable(
    {
      columns: tablecolumns,
      data: tableData,
      initialState: { pageIndex: 0, pageSize: 5 },
    },
    useSortBy,
    usePagination
  );
  const getPagination = () => {
    console.log(pageSize, "pageSize");
    // isServerPagination : true
    // const pageCount = Math.ceil(totalRecords % pageSize)
    const pageCount = parseInt(Math.ceil(tableData.length / pageSize));
    const paginationItems = [];
    for (let i = 1; i <= pageCount; i++) {
      paginationItems.push(
        <a
          href="#"
          onClick={(event) => {
            event.preventDefault();
            gotoPage(i - 1);
          }}
        >
          {i}
        </a>
      );
    }
    return paginationItems.length > 1 ? paginationItems : [];
  };
  return (
    <>
      <table striped bordered hover size="sm" {...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                  {column.render("Header")}
                  <span>
                    {column.isSorted
                      ? column.isSortedDesc
                        ? " 🔽"
                        : " 🔼"
                      : ""}
                  </span>
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {page.map((row, i) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="pagination">
        <a
          href="#"
          onClick={(event) => {
            previousPage();
            event.preventDefault();
          }}
          disabled={!canPreviousPage}
        >
          &laquo;
        </a>
        {getPagination()}
        <a
          href="#"
          onClick={(event) => {
            nextPage();
            event.preventDefault();
          }}
          disabled={!canPreviousPage}
        >
          &raquo;
        </a>
        <span className="pageRecords">
          Page:
          {pageIndex + 1} of {pageOptions.length}
        </span>
        <select
          value={pageSize}
          onChange={(e) => {
            setPageSize(Number(e.target.value));
          }}
        >
          {[5, 10, 20].map((pageSize) => (
            <option key={pageSize} value={pageSize}>
              Show {pageSize}
            </option>
          ))}
        </select>
      </div>
    </>
  );
};

export default DataTable;
