import { configureStore } from "@reduxjs/toolkit";
import LandingPageReducer from "./components/landing-page/landingPageSlice";
import HomePageReducer from "./components/home/homeSlice";

const reducer = {
  landingPage: LandingPageReducer,
  homePage11: HomePageReducer,
};
const store = configureStore({ reducer });

export default store;
