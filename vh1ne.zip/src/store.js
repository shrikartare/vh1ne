import {configureStore} from '@reduxjs/toolkit';
import LandingPageReducer from "./components/landing-page/landingPageSlice";

const store = configureStore({
  reducer: LandingPageReducer
});

export default store;