const ngApiMock = require("@ng-apimock/core");
const devInterface = require("@ng-apimock/dev-interface");
const serveStatic = require("serve-static");

ngApiMock.processor.process({
  echo: true,
  src: "mock-server",
  patterns: {
    mocks: "mock-data/*.json",
    presets: "**/*.preset.json",
  },
  watch: true,
});
module.exports = function (app) {
  app.use(ngApiMock.middleware);
  app.use("/mocks/", serveStatic(devInterface));
};
